# -*- coding: utf-8 -*-
"""
================================================================================
 EXPORTACAO EM PDF  |  Mendes RH x Aviva / Rio Quente Resorts
================================================================================
Monta um PDF A4 paisagem a partir das mesmas secoes que alimentam a tela,
para que relatorio impresso e painel nunca divirjam.

Dependencias:
    pip install reportlab "kaleido==0.2.1"

kaleido 0.2.1 e autocontido (nao exige Chrome instalado). Se voce ja tiver
kaleido >= 1.0 junto com o Google Chrome, tambem funciona.
================================================================================
"""
import html as _html
import io
import re
from datetime import datetime

FALHA_IMPORT = None
try:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import (BaseDocTemplate, Frame, Image, KeepTogether,
                                    PageBreak, PageTemplate, Paragraph, Spacer,
                                    Table, TableStyle)
except Exception as e:                                   # pragma: no cover
    FALHA_IMPORT = f"reportlab não instalado ({e})"

INK = colors.HexColor("#0b0b0b") if not FALHA_IMPORT else None
INK2 = colors.HexColor("#52514e") if not FALHA_IMPORT else None
MUT = colors.HexColor("#898781") if not FALHA_IMPORT else None
AZUL = colors.HexColor("#2a78d6") if not FALHA_IMPORT else None
AZUL_ESC = colors.HexColor("#0d366b") if not FALHA_IMPORT else None
VERDE = colors.HexColor("#1baf7a") if not FALHA_IMPORT else None
LINHA = colors.HexColor("#e1e0d9") if not FALHA_IMPORT else None

LARG, ALT = landscape(A4)
MARGEM = 14 * mm
UTIL = LARG - 2 * MARGEM


def disponivel():
    """(ok, mensagem) — informa se o PDF pode ser gerado neste ambiente."""
    if FALHA_IMPORT:
        return False, FALHA_IMPORT
    try:
        import plotly.graph_objects as go
        go.Figure().to_image(format="png", width=200, height=120)
    except Exception as e:
        msg = str(e).strip().splitlines()
        msg = msg[0] if msg else type(e).__name__
        return False, (f"não foi possível renderizar os gráficos ({msg}). "
                       f"Instale com:  pip install \"kaleido==0.2.1\"")
    return True, ""


# ------------------------------------------------------------------ gráficos
def _fig_png(fig, largura_px=1500, altura_px=None, escala=2):
    """Converte a figura plotly em PNG, com fonte segura para impressão."""
    import copy
    f = copy.deepcopy(fig)
    alt = altura_px or (f.layout.height or 340)

    # Na tela o Streamlit redimensiona e o plotly expande as margens sozinho.
    # Na exportacao o tamanho e fixo, entao garantimos folga para os rotulos
    # dos eixos nao serem cortados.
    m = f.layout.margin
    f.update_layout(
        font=dict(family="Arial, Helvetica, sans-serif"),
        paper_bgcolor="#ffffff", plot_bgcolor="#ffffff",
        width=largura_px, height=int(alt),
        margin=dict(l=max(m.l or 0, 58), r=max(m.r or 0, 24),
                    t=max(m.t or 0, 34), b=max(m.b or 0, 46)))
    try:
        f.update_xaxes(automargin=True)
        f.update_yaxes(automargin=True)
    except Exception:
        pass
    return f.to_image(format="png", scale=escala)


# --------------------------------------------------------------------- texto
def _limpar(t):
    t = re.sub(r"<br\s*/?>", " ", t)
    t = re.sub(r"</?(span|div)[^>]*>", "", t)
    t = re.sub(r"<(?!/?[bi]\b)[^>]+>", "", t)
    return _html.unescape(re.sub(r"\s+", " ", t)).strip()


def _html_para_flowables(bruto, estilos):
    """Converte os blocos de análise (HTML simples) em parágrafos do PDF."""
    saida = []
    for bloco in re.split(r'(?=<div class="note)', bruto):
        if not bloco.strip():
            continue
        cab = re.search(r'<span class="hd">(.*?)</span>', bloco, re.S)
        if cab:
            saida.append(Paragraph(_limpar(cab.group(1)), estilos["sub"]))
        itens = re.findall(r"<li>(.*?)</li>", bloco, re.S)
        if itens:
            for it in itens:
                saida.append(Paragraph(f"• {_limpar(it)}", estilos["corpo"]))
        elif not cab:
            txt = _limpar(bloco)
            if txt:
                saida.append(Paragraph(txt, estilos["corpo"]))
        saida.append(Spacer(1, 3 * mm))
    return saida


def _estilos():
    base = getSampleStyleSheet()
    return {
        "titulo": ParagraphStyle("t", parent=base["Normal"], fontName="Helvetica-Bold",
                                 fontSize=17, leading=21, textColor=INK, spaceAfter=2),
        "sub": ParagraphStyle("s", parent=base["Normal"], fontName="Helvetica-Bold",
                              fontSize=10.5, leading=14, textColor=INK, spaceBefore=2,
                              spaceAfter=3),
        "secao": ParagraphStyle("se", parent=base["Normal"], fontName="Helvetica-Bold",
                                fontSize=12, leading=15, textColor=INK, spaceBefore=4,
                                spaceAfter=1),
        "desc": ParagraphStyle("d", parent=base["Normal"], fontName="Helvetica",
                               fontSize=8.5, leading=11.5, textColor=MUT, spaceAfter=4),
        "corpo": ParagraphStyle("c", parent=base["Normal"], fontName="Helvetica",
                                fontSize=9, leading=13, textColor=INK,
                                alignment=TA_LEFT, spaceAfter=2, leftIndent=4),
        "rodape": ParagraphStyle("r", parent=base["Normal"], fontName="Helvetica",
                                 fontSize=7.5, leading=10, textColor=MUT),
    }


# ------------------------------------------------------------------- tabelas
def _tabela_kpis(tiles, est):
    dados = [[], []]
    for t in tiles:
        dados[0].append(Paragraph(f"<b>{_limpar(t['lb']).upper()}</b>",
                                  ParagraphStyle("k", fontName="Helvetica-Bold",
                                                 fontSize=7, leading=9,
                                                 textColor=colors.white)))
        sub = _limpar(t.get("sb", ""))
        badge = t.get("badge")
        if badge:
            sub = f"{sub} · {_limpar(badge)}"
        dados[1].append(Paragraph(
            f"<b>{_limpar(t['vl'])}</b><br/><font size=7>{sub}</font>",
            ParagraphStyle("v", fontName="Helvetica-Bold", fontSize=15, leading=17,
                           textColor=colors.white)))
    larg = UTIL / max(len(tiles), 1)
    tb = Table(dados, colWidths=[larg] * len(tiles), rowHeights=[9 * mm, 15 * mm])
    tb.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), AZUL_ESC),
        ("VALIGN", (0, 0), (-1, 0), "BOTTOM"),
        ("VALIGN", (0, 1), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, 0), 7),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 7),
        ("LINEAFTER", (0, 0), (-2, -1), 0.6, colors.HexColor("#2a5f9e")),
    ]))
    return tb


def _tabela_df(df, est, max_linhas=40, largura=None):
    df = df.head(max_linhas)
    cab = [Paragraph(f"<b>{c}</b>", ParagraphStyle("th", fontName="Helvetica-Bold",
                                                   fontSize=7.5, leading=9.5,
                                                   textColor=colors.white))
           for c in df.columns]
    linhas = [cab]
    for _, r in df.iterrows():
        linhas.append([Paragraph(str(v), ParagraphStyle("td", fontName="Helvetica",
                                                        fontSize=7.5, leading=9.5,
                                                        textColor=INK))
                       for v in r.tolist()])
    larg = (largura or UTIL) / len(df.columns)
    tb = Table(linhas, colWidths=[larg] * len(df.columns), repeatRows=1)
    tb.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), AZUL),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f7f8fa")]),
        ("GRID", (0, 0), (-1, -1), 0.3, LINHA),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return tb


# --------------------------------------------------------------------- capa
def _cabecalho_rodape(canvas, doc, titulo, logo_bytes, quando):
    canvas.saveState()
    canvas.setFillColor(AZUL_ESC)
    canvas.rect(0, ALT - 11 * mm, LARG, 11 * mm, stroke=0, fill=1)
    canvas.setFillColor(colors.white)
    canvas.setFont("Helvetica-Bold", 9)
    canvas.drawString(MARGEM, ALT - 7.6 * mm, titulo)
    canvas.setFont("Helvetica", 8)
    canvas.drawRightString(LARG - MARGEM, ALT - 7.6 * mm, "Mendes RH · Aviva / Rio Quente")
    canvas.setStrokeColor(LINHA)
    canvas.setLineWidth(0.5)
    canvas.line(MARGEM, 11 * mm, LARG - MARGEM, 11 * mm)
    canvas.setFillColor(MUT)
    canvas.setFont("Helvetica", 7.5)
    canvas.drawString(MARGEM, 7 * mm, f"Gerado em {quando}")
    canvas.drawRightString(LARG - MARGEM, 7 * mm, f"Página {doc.page}")
    canvas.restoreState()


# ------------------------------------------------------------------- geração
def gerar_pdf(secoes, titulo="Relatório de Gestão de Temporários",
              subtitulo="", logo_bytes=None):
    """
    secoes: lista de {"titulo": str, "blocos": [...]} no mesmo formato usado
            para desenhar na tela.
    Retorna os bytes do PDF.
    """
    ok, msg = disponivel()
    if not ok:
        raise RuntimeError(msg)

    est = _estilos()
    quando = datetime.now().strftime("%d/%m/%Y às %H:%M")
    buf = io.BytesIO()

    doc = BaseDocTemplate(buf, pagesize=landscape(A4),
                          leftMargin=MARGEM, rightMargin=MARGEM,
                          topMargin=16 * mm, bottomMargin=15 * mm,
                          title=titulo, author="Mendes RH")
    frame = Frame(MARGEM, 15 * mm, UTIL, ALT - 31 * mm, id="f", showBoundary=0)
    doc.addPageTemplates([PageTemplate(
        id="p", frames=[frame],
        onPage=lambda c, d: _cabecalho_rodape(c, d, titulo, logo_bytes, quando))])

    hist = []
    # ---- capa
    if logo_bytes:
        try:
            img = Image(io.BytesIO(logo_bytes))
            r = img.imageWidth / img.imageHeight
            img.drawHeight = 22 * mm
            img.drawWidth = 22 * mm * r
            img.hAlign = "LEFT"
            hist += [Spacer(1, 6 * mm), img]
        except Exception:
            pass
    hist += [Spacer(1, 8 * mm),
             Paragraph(titulo, ParagraphStyle("cap", fontName="Helvetica-Bold",
                                              fontSize=26, leading=30, textColor=INK)),
             Spacer(1, 2 * mm),
             Paragraph(subtitulo, ParagraphStyle("cap2", fontName="Helvetica",
                                                 fontSize=12, leading=16, textColor=INK2)),
             Spacer(1, 6 * mm),
             Paragraph("Conteúdo: " + " · ".join(s["titulo"] for s in secoes), est["desc"]),
             PageBreak()]

    for i, sec in enumerate(secoes):
        hist.append(Paragraph(sec["titulo"], est["titulo"]))
        if sec.get("sub"):
            hist.append(Paragraph(_limpar(sec["sub"]), est["desc"]))
        hist.append(Spacer(1, 3 * mm))

        for b in sec["blocos"]:
            tipo = b.get("t")
            if tipo == "hero":
                hist.append(_tabela_kpis(b["tiles"], est))
                hist.append(Spacer(1, 5 * mm))
            elif tipo == "fig":
                partes = []
                if b.get("titulo"):
                    partes.append(Paragraph(b["titulo"], est["secao"]))
                if b.get("desc"):
                    partes.append(Paragraph(_limpar(b["desc"]), est["desc"]))
                try:
                    png = _fig_png(b["fig"], largura_px=1150,
                                   altura_px=b.get("altura") or b["fig"].layout.height)
                    im = Image(io.BytesIO(png))
                    r = im.imageWidth / im.imageHeight
                    im.drawWidth = UTIL
                    im.drawHeight = UTIL / r
                    lim = ALT - 62 * mm
                    if im.drawHeight > lim:
                        im.drawHeight, im.drawWidth = lim, lim * r
                    im.hAlign = "CENTER"
                    partes.append(im)
                except Exception as e:
                    partes.append(Paragraph(f"[gráfico não renderizado: {e}]", est["desc"]))
                partes.append(Spacer(1, 4 * mm))
                hist.append(KeepTogether(partes))
            elif tipo in ("texto", "nota"):
                partes = []
                if b.get("titulo"):
                    partes.append(Paragraph(b["titulo"], est["secao"]))
                partes += _html_para_flowables(b["html"], est)
                hist.append(KeepTogether(partes))
            elif tipo == "tabela":
                partes = []
                if b.get("titulo"):
                    partes.append(Paragraph(b["titulo"], est["secao"]))
                if b.get("desc"):
                    partes.append(Paragraph(_limpar(b["desc"]), est["desc"]))
                partes.append(_tabela_df(b["df"], est))
                partes.append(Spacer(1, 4 * mm))
                hist.append(KeepTogether(partes))
            elif tipo == "cards":
                n = max(len(b["itens"]), 1)
                larg = UTIL / n
                celulas = []
                for filho in b["itens"]:
                    conteudo = []
                    for sub_b in filho:
                        conteudo += _blocos_simples(sub_b, est, larg - 6)
                    celulas.append(conteudo)
                tb = Table([celulas], colWidths=[larg] * n)
                tb.setStyle(TableStyle([
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 0),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                    ("TOPPADDING", (0, 0), (-1, -1), 0),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
                ]))
                hist.append(tb)
                hist.append(Spacer(1, 4 * mm))
        if i < len(secoes) - 1:
            hist.append(PageBreak())

    doc.build(hist)
    return buf.getvalue()


def _blocos_simples(b, est, larg=None):
    """Trata um bloco isolado vindo de um agrupamento em colunas."""
    larg = larg or UTIL
    saida = []
    tipo = b.get("t")
    if tipo == "fig":
        if b.get("titulo"):
            saida.append(Paragraph(b["titulo"], est["secao"]))
        if b.get("desc"):
            saida.append(Paragraph(_limpar(b["desc"]), est["desc"]))
        try:
            png = _fig_png(b["fig"], largura_px=700,
                           altura_px=b.get("altura") or b["fig"].layout.height)
            im = Image(io.BytesIO(png))
            r = im.imageWidth / im.imageHeight
            im.drawWidth = larg
            im.drawHeight = im.drawWidth / r
            lim = ALT - 78 * mm
            if im.drawHeight > lim:
                im.drawHeight, im.drawWidth = lim, lim * r
            im.hAlign = "CENTER"
            saida.append(im)
        except Exception as e:
            saida.append(Paragraph(f"[gráfico não renderizado: {e}]", est["desc"]))
        saida.append(Spacer(1, 3 * mm))
    elif tipo in ("texto", "nota"):
        if b.get("titulo"):
            saida.append(Paragraph(b["titulo"], est["secao"]))
        saida += _html_para_flowables(b["html"], est)
    elif tipo == "tabela":
        if b.get("titulo"):
            saida.append(Paragraph(b["titulo"], est["secao"]))
        saida.append(_tabela_df(b["df"], est, largura=larg))
        saida.append(Spacer(1, 4 * mm))
    return saida
